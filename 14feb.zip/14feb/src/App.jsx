import "./App.css";
import LovePage from "./LovePage";

function App() {
  return (
    <>
      <LovePage></LovePage>
    </>
  );
}

export default App;
